#!/usr/bin/python
# -*- coding: utf-8 -*-
import urllib , urllib2 , re , zlib , ast , os , uuid
from xbmcswift2 import Plugin , xbmc , xbmcgui , xbmcaddon
oo000 = Plugin ( )
ii = "plugin://plugin.video.donggiao"
if 51 - 51: IiI1i11I
@ oo000 . route ( '/' )
def Iii1I1 ( ) :
 OOO0O0O0ooooo = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 if 49 - 49: OOO0O0O0ooooo = xbmc . translatePath ( os . path . join ( OOO0O0O0ooooo , "temp.jpg" ) )
 if 49 - 49: urllib . urlretrieve ( 'https://googledrive.com/host/0B-ygKtjD8Sc-S04wUUxMMWt5dmM/images/donggiao.jpg' , OOO0O0O0ooooo )
 if 49 - 49: iIIii1IIi = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , OOO0O0O0ooooo )
 if 49 - 49: o0OO00 = xbmcgui . WindowDialog ( )
 if 49 - 49: o0OO00 . addControl ( iIIii1IIi )
 if 49 - 49: o0OO00 . doModal ( )
 oo = [
 { 'label' : 'Đồng Giao Official' , 'path' : 'plugin://plugin.video.youtube/channel/UCZTjI84dMcWPLMDd7HjzFnA/' , 'thumbnail' : 'https://yt3.ggpht.com/-5TD-pJoIQRY/AAAAAAAAAAI/AAAAAAAAAAA/oBUSns1u68U/s256-c-k-no/photo.jpg' } ,
 { 'label' : 'Dong Giao Pro' , 'path' : 'plugin://plugin.video.youtube/channel/UCkRLTtpdJj-8Of10-N9E9Ug/' , 'thumbnail' : 'https://yt3.ggpht.com/-S280zJuQrK0/AAAAAAAAAAI/AAAAAAAAAAA/qrXrrcjVT28/s256-c-k-no/photo.jpg' } ,
 { 'label' : 'Giang Nguyen' , 'path' : 'plugin://plugin.video.youtube/channel/UCfxY1HzwvH1gBfAG8O-kNwA/' , 'thumbnail' : 'https://yt3.ggpht.com/-FDJoaZ4E_MU/AAAAAAAAAAI/AAAAAAAAAAA/0F0jKAmhaP0/s256-c-k-no/photo.jpg' } ,
 { 'label' : 'MrBeGiang' , 'path' : 'plugin://plugin.video.youtube/channel/UC1L_0MbpbkPRPE01t8neBZg/' , 'thumbnail' : 'https://yt3.ggpht.com/-WbQ8qe3augw/AAAAAAAAAAI/AAAAAAAAAAA/u3YVPUd0U4o/s256-c-k-no/photo.jpg' }
 ]
 return oo000 . finish ( oo )
 if 27 - 27: oO0OooOoO * o0Oo
 if 5 - 5: OoO0O00
if __name__ == '__main__' :
 oo000 . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
