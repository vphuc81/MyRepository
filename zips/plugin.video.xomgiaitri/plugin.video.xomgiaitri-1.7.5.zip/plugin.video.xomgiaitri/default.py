#!/usr/bin/python
# coding=utf8
import xbmc , xbmcaddon , xbmcplugin , xbmcgui , sys , urllib , urllib2 , re , os , zlib , base64 , json , logging , requests , urlresolver
if 64 - 64: i11iIiiIii
OO0o = 'plugin.video.xomgiaitri'
Oo0Ooo = xbmcaddon . Addon ( OO0o )
O0O0OO0O0O0 = int ( sys . argv [ 1 ] )
if 5 - 5: iiI / ii1I
def ooO0OO000o ( ) :
 ii11i = ""
 oOooOoO0Oo0O = ( "Busy" , "Bận" , "Band" , "Beschäftigt" , "Bezig" , "忙" , "忙碌" )
 # while True :
#  sys = urllib . quote ( xbmc . getInfoLabel ( "System.KernelVersion" ) . strip ( ) )
 # if not any ( b in sys for b in oOooOoO0Oo0O ) : break
 #while True :
  #iI1 = urllib . quote ( xbmc . getInfoLabel ( "System.FriendlyName" ) . strip ( ) )
  #if not any ( b in iI1 for b in oOooOoO0Oo0O ) : break
 #try :
  #ii11i = open ( '/sys/class/net/eth0/address' ) . read ( ) . strip ( )
 #except :
  #while True :
   #ii11i = xbmc . getInfoLabel ( "Network.MacAddress" ) . strip ( )
   #if re . match ( "[0-9a-f]{2}([-:])[0-9a-f]{2}(\\1[0-9a-f]{2}){4}$" , ii11i . lower ( ) ) : break
 #i1I11i = urllib2 . urlopen ( "http://www.viettv24.com/main/checkActivation.php?MacID=%s&app_id=%s&sys=%s&dev=%s" % ( ii11i , "16" , sys , iI1 ) ) . read ( )
 if True :
  OoOoOO00 ( 'Search' , 'http://www.mythugian.net/xem/search/%s/1.html' , 'search' , 'http://i.imgur.com/uRDBdIl.jpg' )
  OoOoOO00 ( 'Phim Lẻ' , 'http://www.mythugian.net/xem/the-loai/phim-dien-anh' , 'index' , 'http://i.imgur.com/TD9aIs0.jpg' )
  OoOoOO00 ( 'Phim Bộ' , 'http://www.mythugian.net/xem/the-loai/phim-bo' , 'index' , 'http://i.imgur.com/nEqTWDN.jpg' )
  OoOoOO00 ( 'Phim Bộ theo Quốc Gia' , 'http://www.mythugian.net/' , 'videosbyregion' , 'http://i.imgur.com/Kh1CL2Y.jpg' )
  OoOoOO00 ( 'Phim Lẻ theo Thể Loại' , 'http://www.mythugian.net/' , 'videosbycategory' , 'http://i.imgur.com/IYDKhR8.jpg' )
 else :
  I11i = xbmcgui . Dialog ( )
  I11i . ok ( "Chú ý" , i1I11i )
  if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
  #I11iIi1I = xbmc . translatePath ( os . path . join ( I11iIi1I , "temp.jpg" ) )
 #urllib . urlretrieve ( 'http://drive.google.com/uc?export=jpg&id=0B-ygKtjD8Sc-OUxwbVR5ZzZsbFJFT3A5aS04YlJkdDJtQ3BF' , I11iIi1I )
 #IiiIII111iI = xbmcgui . ControlImage ( 0 , 0 , 1280 , 720 , I11iIi1I )
 #IiII = xbmcgui . WindowDialog ( )
 #IiII . addControl ( IiiIII111iI )
 #IiII . doModal ( )
 if 28 - 28: Ii11111i * iiI1i1
def i1I1ii1II1iII ( ) :
 OoOoOO00 ( "Hồng Kong" , "http://www.mythugian.net/xem/category/1/phim-bo-hong-kong.html" , "index" , "" )
 OoOoOO00 ( "Hồng Kong (VNLT)" , "http://www.mythugian.net/xem/category/28/phim-bo-hong-kong-vnlt.html" , "index" , "" )
 OoOoOO00 ( "Hàn Quốc" , "http://www.mythugian.net/xem/category/4/phim-bo-han-quoc.html" , "index" , "" )
 OoOoOO00 ( "Hàn Quốc (vietsub)" , "http://www.mythugian.net/xem/category/29/phim-bo-han-quoc-vietsub.html" , "index" , "" )
 OoOoOO00 ( "Trung Quốc" , "http://www.mythugian.net/xem/category/2/phim-bo-trung-quoc.html" , "index" , "" )
 OoOoOO00 ( "Đài Loan" , "http://www.mythugian.net/xem/category/3/phim-bo-dai-loan.html" , "index" , "" )
 OoOoOO00 ( "Việt Nam" , "http://www.mythugian.net/xem/category/5/phim-bo-viet-nam.html" , "index" , "" )
 OoOoOO00 ( "Thái Lan" , "http://www.mythugian.net/xem/category/22/phim-bo-thai-lan.html" , "index" , "" )
 OoOoOO00 ( "Các Loại Khác" , "http://www.mythugian.net/xem/category/7/cac-loai-khac.html" , "index" , "" )
 if 86 - 86: oO0o
def IIII ( ) :
 OoOoOO00 ( "Hành Động" , "http://www.mythugian.net/xem/category/8/hanh-dong.html" , "index" , "" )
 OoOoOO00 ( "Tình Cảm" , "http://www.mythugian.net/xem/category/9/tinh-cam.html" , "index" , "" )
 OoOoOO00 ( "Phim Hài" , "http://www.mythugian.net/xem/category/10/phim-hai.html" , "index" , "" )
 OoOoOO00 ( "Kinh Dị" , "http://www.mythugian.net/xem/category/11/kinh-di.html" , "index" , "" )
 OoOoOO00 ( "Kiếm Hiệp" , "http://www.mythugian.net/xem/category/12/kiem-hiep.html" , "index" , "" )
 OoOoOO00 ( "Việt Nam" , "http://www.mythugian.net/xem/category/15/viet-nam.html" , "index" , "" )
 OoOoOO00 ( "Hài Kịch" , "http://www.mythugian.net/xem/category/16/hai-kich.html" , "index" , "" )
 OoOoOO00 ( "Ca Nhạc" , "http://www.mythugian.net/xem/category/17/ca-nhac.html" , "index" , "" )
 OoOoOO00 ( "Cải Lương" , "http://www.mythugian.net/xem/category/18/cai-luong.html" , "index" , "" )
 OoOoOO00 ( "Phóng Sự" , "http://www.mythugian.net/xem/category/19/phong-su.html" , "index" , "" )
 OoOoOO00 ( "Các Loại Khác" , "http://www.mythugian.net/xem/category/20/cac-loai-khac.html" , "index" , "" )
 if 59 - 59: II1i * o00ooo0 / o00 * Oo0oO0ooo
def o0oOoO00o ( url ) :
 i1oOOoo00O0O = i1111 ( url )
 i11 = re . compile ( '<td align="center"><a href=".(.+?)" title="(.+?)"><img src="(.+?)"[^>]*/></a>' ) . findall ( i1oOOoo00O0O )
 for I11 , Oo0o0000o0o0 , oOo0oooo00o in i11 :
  oOo0oooo00o = oOo0oooo00o . replace ( "xomgiaitri.com" , "mythugian.net" )
  oOo0oooo00o = oOo0oooo00o . replace ( "www." , "" )
  oOo0oooo00o = "/" . join ( oOo0oooo00o . split ( "/" ) [ : - 1 ] ) + "/" + urllib . quote ( oOo0oooo00o . split ( "/" ) [ - 1 ] )
  OoOoOO00 ( "[B]" + Oo0o0000o0o0 + "[/B]" , "http://www.mythugian.net/xem" + I11 , 'mirrors' , oOo0oooo00o )
 oO0o0o0ooO0oO = re . compile ( '<a class="pagelink" [^>]* href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( i1oOOoo00O0O . replace ( "'" , '"' ) )
 for I11 , oo0o0O00 in oO0o0o0ooO0oO :
  OoOoOO00 ( oo0o0O00 , I11 . replace ( "./" , "http://www.mythugian.net/xem/" ) , 'index' , "" )
  if 68 - 68: o00oo . iI1OoOooOOOO + i11iiII
def I1iiiiI1iII ( ) :
 try :
  IiIi11i = xbmc . Keyboard ( '' , 'Enter search text' )
  IiIi11i . doModal ( )
  if 43 - 43: o0O0 * O00O0O0O0
  if ( IiIi11i . isConfirmed ( ) ) :
   ooO0O = urllib . quote_plus ( IiIi11i . getText ( ) )
  o0oOoO00o ( oo % ooO0O )
 except : pass
 if 28 - 28: i1iIIIiI1I - Oo0oO0ooo
def OoO000 ( url ) :
 IIiiIiI1 = iiIiIIi ( url )
 i1oOOoo00O0O = i1111 ( IIiiIiI1 )
 ooOoo0O = re . compile ( '<span class="name"[^>]*>(.+?)</span>' ) . findall ( i1oOOoo00O0O )
 if 76 - 76: iiI / II1i . IIIiiIIii * iI1OoOooOOOO - Oo0oO0ooo
 if "Server VIP B :" in ooOoo0O :
  ooOoo0O . insert ( 0 , ooOoo0O . pop ( ooOoo0O . index ( "Server VIP B :" ) ) )
 if "Server VIP A :" in ooOoo0O :
  ooOoo0O . insert ( 0 , ooOoo0O . pop ( ooOoo0O . index ( "Server VIP A :" ) ) )
 if "Server VIP D :" in ooOoo0O :
  ooOoo0O . insert ( 0 , ooOoo0O . pop ( ooOoo0O . index ( "Server VIP D :" ) ) )
 for Oooo in range ( len ( ooOoo0O ) ) :
  O00o = [ ]
  if not any ( x in ooOoo0O [ Oooo ] for x in O00o ) :
   OoOoOO00 ( "[%d] - %s" % ( Oooo + 1 , ooOoo0O [ Oooo ] ) , IIiiIiI1 . encode ( "utf-8" ) , 'episodes' , "" )
   if 61 - 61: i11iiII . ii1I * IIIiiIIii . i1iIIIiI1I % Ii11111i
def oOo00Oo00O ( url , name ) :
 i1oOOoo00O0O = i1111 ( url )
 if 43 - 43: IIIiiIIii - i11iiII * ii1I
 name = name . split ( "] - " ) [ 1 ]
 O0O00o0OOO0 = re . compile ( '<div class="listserver"><span class="name"[^>]*>%s</span>(.+?)</div>' % name ) . findall ( i1oOOoo00O0O )
 Ii1iIIIi1ii = re . compile ( '<a href="(.+?)"><font[^>]*><b>(.+?)</b></font></a>' ) . findall ( O0O00o0OOO0 [ 0 ] )
 if ( "episode_bg_2" in O0O00o0OOO0 [ 0 ] ) :
  o0oo0o0O00OO = re . compile ( '<font class="episode_bg_2">(.+?)</font>' ) . findall ( O0O00o0OOO0 [ 0 ] )
  o0oO ( "Part - " + o0oo0o0O00OO [ 0 ] . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , url , 'loadvideo' , '' , name . encode ( "utf-8" ) )
 for I1i1iii , i1iiI11I in Ii1iIIIi1ii :
  o0oO ( "Part - " + i1iiI11I . replace ( "&nbsp;" , "" ) . strip ( ) . encode ( "utf-8" ) , "http://www.mythugian.net/xem/" + I1i1iii , 'loadvideo' , '' , name . encode ( "utf-8" ) )
  if 29 - 29: OOooo000oo0
def iiIiIIi ( url ) :
 iI = i1111 ( url )
 return re . compile ( '<p class="w_now"><a href="(.+?)" title="Xem phim trực tuyến">' ) . findall ( iI ) [ 0 ]
 if 28 - 28: Oo0oO0ooo - o0O0 . o0O0 + oO0o - OOooo000oo0 + iiI
def oOoOooOo0o0 ( url , name ) :
 OOOO = xbmcgui . ListItem ( name )
 i1oOOoo00O0O = i1111 ( url )
 if ( "proxy.link" in i1oOOoo00O0O ) :
  OOO00 = re . compile ( "'proxy.link', '(.+?)'" ) . findall ( i1oOOoo00O0O )
  i1oOOoo00O0O = i1111 ( OOO00 [ 0 ] )
 OOO00 = re . compile ( '<source src="(.+?)" type="video/mp4">' ) . findall ( i1oOOoo00O0O )
 if ( len ( OOO00 ) == 0 ) :
  iiiiiIIii = None
  if "app.box.com" in i1oOOoo00O0O :
   O000OO0 = re . compile ( 'https://app.box.com/embed_widget/s/(.+?)\?' ) . findall ( i1oOOoo00O0O ) [ 0 ]
   i1I11i = i1111 ( "https://app.box.com/index.php?rm=preview_embed&sharedName=%s" % O000OO0 )
   I11iii1Ii = json . loads ( i1I11i ) [ "file" ] [ "versionId" ]
   iiiiiIIii = "https://app.box.com/representation/file_version_%s/video_480.mp4?shared_name=%s" % ( I11iii1Ii , O000OO0 )
  elif "drive.google.com/file" in i1oOOoo00O0O :
   I1IIiiIiii = re . compile ( '"https://drive.google.com/file/d/(.+?)/.+?"' ) . findall ( i1oOOoo00O0O ) [ 0 ]
   iiiiiIIii = O000oo0O ( I1IIiiIiii )
   OOOO . setPath ( iiiiiIIii )
  elif "openload" in i1oOOoo00O0O :
   try :
    iiiiiIIii = re . compile ( '"(https://openload.+?)"' ) . findall ( i1oOOoo00O0O ) [ 0 ]
    iiiiiIIii = urlresolver . resolve ( iiiiiIIii )
   except :
    pass
  OOOO . setPath ( iiiiiIIii )
 else :
  if "http://" not in OOO00 [ 0 ] :
   OOO00 [ 0 ] = "http://www.mythugian.net/xem/" + OOO00 [ 0 ]
  OOOO . setPath ( OOO00 [ 0 ] )
 OOOO . setProperty ( "IsPlayable" , "true" )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OOOO )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OOOO )
 if 66 - 66: o00ooo0 / oO0o - IIIiiIIii . Oo0oO0ooo / IIIiiIIii * Oo0oO0ooo
def O000oo0O ( drive_id ) :
 IIIii1II1II = "https://drive.google.com/uc?export=download&id=%s" % drive_id
 i1I11i = requests . get ( "https://drive.google.com/file/d/%s" % drive_id )
 if "fmt_stream_map" in i1I11i . text :
  i1I1iI = json . loads ( re . compile ( '(\["fmt_stream_map".+?\])' ) . findall ( i1I11i . text ) [ 0 ] )
  try :
   IIIii1II1II = re . compile ( "22\|(.+?)," ) . findall ( i1I1iI [ 1 ] ) [ 0 ]
  except :
   IIIii1II1II = re . compile ( "18\|(.+?)," ) . findall ( i1I1iI [ 1 ] ) [ 0 ]
  oo0OooOOo0 = "|User-Agent=%s&Cookie=%s" % ( urllib . quote ( i1I11i . request . headers [ "User-Agent" ] ) , urllib . quote ( i1I11i . headers [ "Set-Cookie" ] ) )
  IIIii1II1II += oo0OooOOo0
  if 92 - 92: i11iiII . o00oo + II1i
 else :
  IiII1I11i1I1I = requests . Session ( )
  i1I11i = IiII1I11i1I1I . head ( IIIii1II1II )
  oO0Oo = ""
  for oOOoo0Oo , o00OO00OoO in i1I11i . cookies . iteritems ( ) :
   if "download_warning_" in oOOoo0Oo :
    oO0Oo = o00OO00OoO
  if oO0Oo != "" :
   OOOO0OOoO0O0 = "%s&confirm=%s" % ( IIIii1II1II , oO0Oo )
   i1I11i = IiII1I11i1I1I . head ( OOOO0OOoO0O0 )
   if i1I11i . status_code == 302 :
    IIIii1II1II = OOOO0OOoO0O0
 return IIIii1II1II
 if 65 - 65: o0O0 * IIIiiIIii + iI1OoOooOOOO % i11iIiiIii * o00 . O00O0O0O0
def OoO0O00 ( url ) :
 I1IIiiIiii = ""
 IIiII = urllib2 . Request ( url )
 IIiII . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 IIiII . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 o0 = urllib2 . urlopen ( IIiII )
 url = o0 . geturl ( )
 try :
  I1IIiiIiii = re . compile ( '"https://drive.google.com/file/d/(.+?)/.+?"' ) . findall ( url ) [ 0 ]
 except :
  pass
 o0 . close ( )
 return I1IIiiIiii
 if 62 - 62: ii1I * oO0o
def i1111 ( url ) :
 IIiII = urllib2 . Request ( url )
 IIiII . add_header ( 'User-Agent' , 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; WOW64; Trident/6.0)' )
 IIiII . add_header ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8' )
 o0 = urllib2 . urlopen ( IIiII )
 i1oOOoo00O0O = o0 . read ( )
 o0 . close ( )
 i1oOOoo00O0O = '' . join ( i1oOOoo00O0O . splitlines ( ) ) . replace ( '\'' , '"' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\n' , '' )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '\t' , '' )
 i1oOOoo00O0O = re . sub ( '  +' , ' ' , i1oOOoo00O0O )
 i1oOOoo00O0O = i1oOOoo00O0O . replace ( '> <' , '><' )
 return i1oOOoo00O0O
 if 26 - 26: i11iiII . O00O0O0O0
def o0oO ( name , url , mode , iconimage , mirrorname ) :
 oOOOOo0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&mirrorname=" + urllib . quote_plus ( mirrorname )
 iiII1i1 = True
 o00oOO0o = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 o00oOO0o . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 o00oOO0o . setProperty ( "IsPlayable" , "true" )
 iiII1i1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOOOOo0 , listitem = o00oOO0o )
 return iiII1i1
 if 80 - 80: o00 + Oo0oO0ooo - Oo0oO0ooo % i11iiII
def OoOoOO00 ( name , url , mode , iconimage ) :
 oOOOOo0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name )
 iiII1i1 = True
 o00oOO0o = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 o00oOO0o . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 iiII1i1 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = oOOOOo0 , listitem = o00oOO0o , isFolder = True )
 return iiII1i1
 if 63 - 63: IIIiiIIii - o00ooo0 + iiI % o00oo / ii1I / II1i
def O0o0O00Oo0o0 ( k , e ) :
 O00O0oOO00O00 = [ ]
 e = base64 . urlsafe_b64decode ( e )
 for Oooo in range ( len ( e ) ) :
  i1Oo00 = k [ Oooo % len ( k ) ]
  i1i = chr ( ( 256 + ord ( e [ Oooo ] ) - ord ( i1Oo00 ) ) % 256 )
  O00O0oOO00O00 . append ( i1i )
 return "" . join ( O00O0oOO00O00 )
 if 50 - 50: o0O0
def i11I1iIiII ( parameters ) :
 oO00o0 = { }
 if 55 - 55: Ii11111i + ii1I / oO0o * o00 - i11iIiiIii - iI1OoOooOOOO
 if parameters :
  ii1ii1ii = parameters [ 1 : ] . split ( "&" )
  for oooooOoo0ooo in ii1ii1ii :
   I1I1IiI1 = oooooOoo0ooo . split ( '=' )
   if ( len ( I1I1IiI1 ) ) == 2 :
    oO00o0 [ I1I1IiI1 [ 0 ] ] = I1I1IiI1 [ 1 ]
 return oO00o0
 if 5 - 5: II1i * i1iIIIiI1I + oO0o . Oo0oO0ooo + oO0o
oO = xbmc . translatePath ( Oo0Ooo . getAddonInfo ( 'profile' ) )
if 7 - 7: II1i - IIIiiIIii
if os . path . exists ( oO ) == False :
 os . mkdir ( oO )
OOo00O0 = os . path . join ( oO , 'visitor' )
if 73 - 73: i1 + IIIiiIIii
if os . path . exists ( OOo00O0 ) == False :
 from random import randint
 iII = open ( OOo00O0 , "w" )
 iII . write ( str ( randint ( 0 , 0x7fffffff ) ) )
 iII . close ( )
 if 38 - 38: O00O0O0O0
def Ii1 ( utm_url ) :
 OOooOO000 = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 import urllib2
 try :
  IIiII = urllib2 . Request ( utm_url , None ,
 { 'User-Agent' : OOooOO000 }
 )
  o0 = urllib2 . urlopen ( IIiII ) . read ( )
 except :
  print ( "GA fail: %s" % utm_url )
 return o0
 if 97 - 97: o00ooo0 + Oo0oO0ooo / ii1I / i11iiII
def I1111IIi ( group , name ) :
 try :
  try :
   from hashlib import md5
  except :
   from md5 import md5
  from random import randint
  import time
  from urllib import unquote , quote
  from os import environ
  from hashlib import sha1
  Oo0oO = "1.0"
  IIiIi1iI = open ( OOo00O0 ) . read ( )
  i1IiiiI1iI = "XomGiaiTri"
  i1iIi = "UA-52209804-2"
  ooOOoooooo = "www.viettv24.com"
  II1I = "http://www.google-analytics.com/__utm.gif"
  if name == "None" :
   O0 = II1I + "?" + "utmwv=" + Oo0oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1IiiiI1iI ) + "&utmac=" + i1iIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , IIiIi1iI , "1" , "1" , "2" ] )
   if 5 - 5: O00O0O0O0
   if 87 - 87: o00oo - ii1I + IIIiiIIii . i11iiII
   if 62 - 62: iiI * i1 * II1i - IIIiiIIii + IIIiiIIii
   if 34 - 34: ii1I - II1i
   if 91 - 91: i11iiII % i1 % ii1I
  else :
   if group == "None" :
    O0 = II1I + "?" + "utmwv=" + Oo0oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1IiiiI1iI + "/" + name ) + "&utmac=" + i1iIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , IIiIi1iI , "1" , "1" , "2" ] )
    if 20 - 20: Oo0oO0ooo % iI1OoOooOOOO / iI1OoOooOOOO + iI1OoOooOOOO
    if 45 - 45: o00 - o0O0 - OOooo000oo0 - iiI1i1 . ii1IiI1i / iiI
    if 51 - 51: iiI + i11iiII
    if 8 - 8: o00 * oO0o - iI1OoOooOOOO - iiI1i1 * Oo0oO0ooo % IIIiiIIii
    if 48 - 48: iiI
   else :
    O0 = II1I + "?" + "utmwv=" + Oo0oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmp=" + quote ( i1IiiiI1iI + "/" + group + "/" + name ) + "&utmac=" + i1iIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , IIiIi1iI , "1" , "1" , "2" ] )
    if 11 - 11: o00oo + OOooo000oo0 - iiI1i1 / II1i + Ii11111i . ii1IiI1i
    if 41 - 41: iI1OoOooOOOO - iiI - iiI
    if 68 - 68: Oo0oO0ooo % O00O0O0O0
    if 88 - 88: ii1I - i1iIIIiI1I + Oo0oO0ooo
    if 40 - 40: IIIiiIIii * iI1OoOooOOOO + Oo0oO0ooo % i11iiII
    if 74 - 74: o00 - Ii11111i + OOooo000oo0 + O00O0O0O0 / oO0o
  print "============================ POSTING ANALYTICS ============================"
  Ii1 ( O0 )
  if 23 - 23: iiI
  if not group == "None" :
   o00oO0oOo00 = II1I + "?" + "utmwv=" + Oo0oO + "&utmn=" + str ( randint ( 0 , 0x7fffffff ) ) + "&utmhn=" + quote ( ooOOoooooo ) + "&utmt=" + "events" + "&utme=" + quote ( "5(" + i1IiiiI1iI + "*" + group + "*" + name + ")" ) + "&utmp=" + quote ( i1IiiiI1iI ) + "&utmac=" + i1iIi + "&utmcc=__utma=%s" % "." . join ( [ "1" , "1" , "1" , IIiIi1iI , "1" , "2" ] )
   if 81 - 81: iiI1i1
   if 42 - 42: iiI1i1 / o00oo / II1i + i11iiII / oO0o
   if 84 - 84: i1iIIIiI1I * ii1IiI1i + Ii11111i
   if 53 - 53: i11iiII % ii1IiI1i . o0O0 - ii1I - o0O0 * ii1IiI1i
   if 77 - 77: ii1I * iiI1i1
   if 95 - 95: IIIiiIIii + i11iIiiIii
   if 6 - 6: i1iIIIiI1I / i11iIiiIii + i11iiII * o00
   if 80 - 80: ii1IiI1i
   try :
    print "============================ POSTING TRACK EVENT ============================"
    Ii1 ( o00oO0oOo00 )
   except :
    print "============================  CANNOT POST TRACK EVENT ============================"
    if 83 - 83: o00oo . i11iIiiIii + ii1IiI1i . II1i * o00oo
 except :
  print "================  CANNOT POST TO ANALYTICS  ================"
  if 53 - 53: ii1IiI1i
i1Ii1Ii = i11I1iIiII ( sys . argv [ 2 ] )
oOO = i1Ii1Ii . get ( 'mode' )
oo = i1Ii1Ii . get ( 'url' )
ii1iII1II = i1Ii1Ii . get ( 'name' )
if type ( oo ) == type ( str ( ) ) :
 oo = urllib . unquote_plus ( oo )
if type ( ii1iII1II ) == type ( str ( ) ) :
 ii1iII1II = urllib . unquote_plus ( ii1iII1II )
 if 48 - 48: ii1IiI1i * iI1OoOooOOOO . o00oo + o00
OoO0o = str ( sys . argv [ 1 ] )
if oOO == 'index' :
 I1111IIi ( "Browse" , ii1iII1II )
 o0oOoO00o ( oo )
elif oOO == 'search' :
 I1111IIi ( "None" , "Search" )
 I1iiiiI1iII ( )
elif oOO == 'videosbyregion' :
 I1111IIi ( "Browse" , ii1iII1II )
 i1I1ii1II1iII ( )
elif oOO == 'videosbycategory' :
 I1111IIi ( "Browse" , ii1iII1II )
 IIII ( )
elif oOO == 'mirrors' :
 I1111IIi ( "Browse" , ii1iII1II )
 OoO000 ( oo )
elif oOO == 'episodes' :
 I1111IIi ( "Browse" , ii1iII1II )
 oOo00Oo00O ( oo , ii1iII1II )
elif oOO == 'loadvideo' :
 I1111IIi ( "Play" , ii1iII1II + "/" + oo )
 oO0o0Ooooo = xbmcgui . DialogProgress ( )
 oO0o0Ooooo . create ( 'xomgiaitri.com' , 'Loading video. Please wait...' )
 oOoOooOo0o0 ( oo , ii1iII1II )
 oO0o0Ooooo . close ( )
 del oO0o0Ooooo
else :
 I1111IIi ( "None" , "None" )
 ooO0OO000o ( )
xbmcplugin . endOfDirectory ( int ( OoO0o ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
