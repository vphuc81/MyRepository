# script.module.metahandler
Metahandler Script Module for Kodi

Author: Eldorado

Credits to the many who have supplied code fixes

Scrape for movie and tv show meta data from within a Kodi addon from the following sources:
 - TMDB
 - OMDB
 - TheTVDB


 Usage:

 Begin by importing the metahandler library

 ```python
    import metahandlers
 ```

 
